def function1():
    print("funtion 1")